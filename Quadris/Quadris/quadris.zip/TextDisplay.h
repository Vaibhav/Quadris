
#include "Display.h";


class TextDisplay : public Display {
public:


private:

};
